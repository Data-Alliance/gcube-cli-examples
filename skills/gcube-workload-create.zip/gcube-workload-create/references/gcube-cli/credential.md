# gcube credential 명령

## PURPOSE
gcube CLI의 credential 명령 가이드. 외부 컨테이너 레지스트리·서비스
자격 증명 관리에 사용.

## CONTEXT — 본 스킬에서의 사용

본 스킬은 기본적으로 ghcr.io 의 public 이미지를 사용하므로 자격
증명 등록이 필요 없다. 다음 경우에만 사용:
- private 이미지 사용
- AWS ECR 등 외부 레지스트리 이미지 사용
- Docker Hub 의 private 이미지

## STRUCTURE — 사용 가능한 명령

| 명령 | 목적 | 본 스킬 사용? |
|---|---|---|
| `credential list` | 등록된 자격 증명 조회 | O |
| `credential create` | 새 자격 증명 등록 | △ (필요 시) |
| `credential delete` | 자격 증명 삭제 | X (사용자 자산 변경) |

## CONSIDERATIONS

### 1. credential list

```bash
gcube credential list
```

private 이미지 사용 시 자격 증명이 이미 등록되어 있는지 확인.

### 2. credential create — 필요 시만

```bash
gcube credential create \
  --repo <레지스트리> \
  --username <사용자명> \
  --token <토큰> \
  [--region <AWS 리전>]
```

본 스킬에서 자격 증명 등록이 필요한 경우:
1. 사용자에게 어떤 레지스트리의 자격 증명이 필요한지 확인
2. 사용자가 토큰·키 제공
3. 명령 실행

## CONSTRAINTS
- `credential delete` 본 스킬에서 사용 X
- 사용자가 명시적으로 요청하지 않은 자격 증명 등록 X
- 자격 증명 정보를 로그에 출력 X
