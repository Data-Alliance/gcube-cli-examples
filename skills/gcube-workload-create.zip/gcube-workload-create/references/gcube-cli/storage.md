# gcube storage 명령

## PURPOSE
gcube CLI의 storage 명령 가이드. 클라우드 저장소 조회에 사용.

## STRUCTURE — 사용 가능한 명령

| 명령 | 목적 |
|---|---|
| `storage list` | 사용 가능한 클라우드 저장소 목록 조회 |

## CONSIDERATIONS

### 1. storage list — 저장소 마운트 전 확인

```bash
gcube storage list
```

워크로드에 클라우드 저장소를 마운트할 때 사용 가능한 저장소를 먼저 확인.
워크로드 yml의 `userStorages.storage` 필드에 사용할 저장소 이름을 확인.

⚠ 마운트 경로는 사용자가 결정한다.
상세는 `workload-yml.md` 의 7번 항목 참조.

## CONSTRAINTS
- 사용자가 결정한 저장소 외 임의 선택 X
