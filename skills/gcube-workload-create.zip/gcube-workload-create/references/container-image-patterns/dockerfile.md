# Dockerfile 패턴

## PURPOSE
Dockerfile 작성 시 고려해야 할 핵심 포인트.

## CONSIDERATIONS — 작성 시 고려할 점

### 1. 베이스 이미지 선택 — CUDA 버전

- gcube 환경 표준: **CUDA 12.9**
- RTX 5090 단일 자원에 한해 13.0 가능 (사용자가 명시한 경우만)
- 베이스 이미지 태그가 실제 존재하는지 서칭 검증 필수
- 학습 내용으로 단정 X

### 2. 베이스 이미지 선택 — devel vs runtime (중요)

PyTorch·CUDA 베이스 이미지는 보통 두 종류가 있다:

| 종류 | 포함 내용 | 크기 | 사용 시점 |
|---|---|---|---|
| `devel` | 컴파일러·헤더·개발 도구 포함 | 큼 (~15GB) | 컨테이너 안에서 추가 컴파일·빌드 필요 시 |
| `runtime` | 실행 환경만 | 작음 (~5GB) | 단순 실행만 필요 시 |

**판단 기준**:
- 다음 중 하나라도 해당되면 → **devel 사용**:
  - pip install 시 C/C++ 확장 빌드 필요한 패키지 사용 (예: flash-attn, xformers, bitsandbytes 등)
  - requirements.txt 에 빌드 의존성 있는 패키지 포함
  - 컨테이너 안에서 추가 컴파일이 필요한 작업
  - 커스텀 노드·확장 모듈 설치가 필요한 서비스 (예: ComfyUI Custom Nodes)
  - 일반적인 AI/ML 서비스 (PyTorch + 의존성)
- 다음만 해당되면 → **runtime 사용 가능**:
  - 컨테이너 안에서 추가 빌드 절대 없음
  - 미리 빌드된 wheel·패키지만 사용
  - 단순 실행 환경만 필요

**일반적인 추천**:
- AI/ML 서비스(ComfyUI, vLLM, Stable Diffusion 등)는 거의 다 **devel 필요**
- 서비스가 *"빌드가 필요하지 않다고 확실히 말할 수 있는 경우"* 만 runtime
- **모르겠으면 devel 선택** (안전한 선택. runtime으로 시작했다가 빌드 오류 만나면 다시 devel로 가야 함)

⚠ devel·runtime 결정 시 사용자에게 *"왜 그 선택을 했는지"* 근거와 함께
설명. 학습 내용으로 *"보통 runtime이 가볍다"* 같은 일반론 추천 X.

### 3. PEP 668 우회
Ubuntu 24.04+ 시스템 Python은 pip 설치 차단됨.
컨테이너 안에서 pip install이 실패할 수 있다.
`ENV PIP_BREAK_SYSTEM_PACKAGES=1` 또는 `pip install --break-system-packages` 로 우회.

### 4. 이미지 크기 최소화
이미지가 크면 빌드·배포·기동 모두 느려진다. 다음 옵션 고려:
- `apt-get install --no-install-recommends`
- `apt-get` 후 `rm -rf /var/lib/apt/lists/*`
- `pip install --no-cache-dir`

### 5. 디렉토리 사전 생성
entrypoint.sh가 첫 기동 시 사용할 디렉토리는 Dockerfile에서 미리 생성한다.
서비스가 디렉토리 없으면 오류 발생할 수 있음
(예: ComfyUI v0.21+ 의 user/default 누락 시 userdata 404).

### 6. entrypoint 위치
`/usr/local/bin/entrypoint.sh` 사용 권장 (시스템 PATH 포함).
복사 후 `chmod +x` 로 실행 권한 부여 필수.

### 7. 이미지 메타데이터 (선택)
`LABEL` 로 maintainer·purpose·version 등을 명시하면 이미지 관리·검색 시 유용.

### 8. WORKDIR 설계
서비스 디렉토리 안에서 작업할 거면 git clone 후 `WORKDIR <서비스>` 로 이동.
의존성 설치·entrypoint 실행이 자연스러워짐.

## CONSTRAINTS
- 베이스 이미지·패키지 버전을 학습 내용으로 단정 X. 항상 서칭 검증
- CUDA 13.0 사용 시 사용자 명시 허락 필수 (RTX 5090 외 사용 X)
- 사용자와 협의하지 않은 추가 명령 X

## REFERENCE
참고용 풀 예시가 필요하면: github.com/chaeyoon-08/gcube-cli-seminar (ComfyUI 사례)
