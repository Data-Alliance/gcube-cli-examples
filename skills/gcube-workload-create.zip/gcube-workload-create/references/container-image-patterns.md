# 컨테이너 이미지 패턴

## PURPOSE

본 스킬에서 컨테이너 이미지를 만들 때 따라야 할 패턴을 정리한 문서.
본 문서는 인덱스 역할이며, 각 파일별 세부 가이드는 하위 문서를 참조한다.

## CONTEXT — 왜 자체 제작 이미지가 필요한가

공식 이미지를 그대로 쓰면 매번 컨테이너에 들어가서 필요한 패키지를
일일이 설치해야 한다. 매번 설치하는 게 비효율적이라, 한 번 만들어둔
이미지에 필요한 것들이 다 들어가 있게 하는 게 편하다.

다음 경우에 커스텀 이미지가 필요하다:
- 원하는 버전의 공식 이미지가 없을 때
- 원하는 기능 몇 개가 빠져 있을 때
- 여러 패키지·도구 조합이 필요할 때
- 첫 기동 시 자동화(모델 다운로드 등)가 필요할 때

## STRUCTURE — 기본 구성 (4개 파일)

```
.
├── Dockerfile             # 환경 정의 (베이스 이미지 + 패키지 설치)
├── entrypoint.sh          # 첫 기동 시 자동화 (모델 다운로드·서비스 시작)
├── .github/
│   └── workflows/
│       └── build.yml      # GitHub Actions 자동 빌드 → ghcr push
└── .dockerignore          # 빌드 컨텍스트 최소화
```

특별한 상황이 아니면 이 기본 구성으로 진행한다.
서비스·구성에 따라 추가 파일이 필요하면 SKILL.md의 *"이미지 구성 기본 전제"*
섹션의 유연성 규칙을 따른다.

## REFERENCE INDEX — 세부 가이드 참조 시점

작업 시 다음 파일을 *"해당 시점에만"* 참조한다:

| 파일 | 참조 시점 |
|---|---|
| `container-image-patterns/dockerfile.md` | Dockerfile 작성·검증 시 |
| `container-image-patterns/entrypoint.md` | entrypoint.sh 작성·검증 시 |
| `container-image-patterns/github-actions.md` | build.yml 작성·GitHub Actions 설정 시 |

`.dockerignore` 는 단순하므로 별도 문서 없이 본 문서 하단(STANDARD 섹션)
에 정리한다.

## STANDARD — .dockerignore 기본 항목

빌드 컨텍스트 최소화를 위해 다음을 기본 포함:

```
.git
.github
.gitignore
.dockerignore
README.md
LICENSE
*.md
.vscode
.idea
__pycache__
*.pyc
.DS_Store
node_modules
```

서비스 특성에 따라 추가 항목이 필요하면 사용자와 협의 후 추가한다.

## CONSTRAINTS — 작업 시 핵심 원칙

- 학습된 내용으로 답변 X. 항상 서칭 후 URL 함께 제시
- 서칭 정보는 항상 최신 기준 (발행일 확인)
- 버전·패키지·태그는 반드시 사실 확인 (두세 번 검증)
- CUDA 12.9 기준 (RTX 5090 단일 자원 외에는 13.0 X)
- 빌드 오류 발생 시 메시지 그대로 분석 (추측 X)
- 사용자와 협의한 방식대로 작업할 것 (임의 변경 X)
