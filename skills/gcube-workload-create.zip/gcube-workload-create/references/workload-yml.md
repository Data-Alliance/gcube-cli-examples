# 워크로드 yml 패턴

## PURPOSE
gcube 워크로드 등록 시 사용하는 yml 파일의 표준 구조와 작성 시
고려해야 할 핵심 포인트.

## CONTEXT — 워크로드 yml의 역할
gcube CLI 또는 웹 콘솔로 워크로드 등록 시 사용. 다음을 정의:
- 어떤 이미지를 띄울지
- 어떤 자원(GPU·CPU·메모리)을 할당할지
- 환경변수·포트·마운트 등 실행 설정

## STRUCTURE — 워크로드 yml 구조

### 정식 yml 구조 확인 방법

```bash
# gcube CLI가 제공하는 정식 yml 템플릿 출력
gcube workload register --skeleton
```

이 명령으로 정식 구조·필드를 확인한 후 yml 작성. 학습된 구조로 단정 X.

### 단일 컨테이너 yml (기본)

가장 일반적인 워크로드는 단일 컨테이너 구조다.

```yaml
description: ""
cuda: ""
sharedMemory: 1

containers:
  - containerImage: "ghcr.io/<owner>/<image>:<tag>"
    repo: ghcr.io
    port: 0
    maxConnection: 4
    containerEnvs: []
    userStorages: []

gpuSpecs:
  - gpuCode: ""
```

### 멀티 컨테이너 yml

워크로드 1개에 컨테이너 여러 개를 띄울 수 있다.

```yaml
description: ""
cuda: ""
sharedMemory: 16    # 컨테이너 간 공유 메모리

containers:
  # 컨테이너 1
  - containerImage: "ghcr.io/<owner>/<image1>:<tag>"
    repo: ghcr.io
    port: 8188
    maxConnection: 4
    containerEnvs: []
    userStorages: []
  # 컨테이너 2
  - containerImage: "ghcr.io/<owner>/<image2>:<tag>"
    repo: ghcr.io
    port: 3000
    maxConnection: 10
    containerEnvs: []
    userStorages: []

gpuSpecs:
  - gpuCode: ""
```

⚠ GPU는 컨테이너별로 할당되지 않는다. 워크로드 전체에 할당되고 컨테이너들이
공유한다. 컨테이너별 GPU 분리가 필요하면 별도 워크로드로 분리 권장.

### 멀티 레플리카 yml

같은 컨테이너를 여러 개 띄워 부하 분산. `gpuSpecs` 에 항목을 추가하면 그 수만큼
복제된다.

```yaml
description: ""
cuda: ""
sharedMemory: 1

containers:
  - containerImage: "ghcr.io/<owner>/<image>:<tag>"
    repo: ghcr.io
    port: 8188
    maxConnection: 4
    containerEnvs: []
    userStorages: []

gpuSpecs:
  - gpuCode: "025"
  # 추가 레플리카는 gpuSpecs 항목 추가
  - gpuCode: "025"
  - gpuCode: "025"
```

⚠ 레플리카는 같은 이미지로 같은 설정이 복제된다. 컨테이너별로 다른 설정을 원하면
멀티 컨테이너 구조를 사용한다.

### 어떤 구조를 쓸까

| 구조 | 사용 시점 |
|---|---|
| 단일 컨테이너 | 가장 일반적. 한 서비스만 띄울 때 |
| 멀티 컨테이너 | 한 워크로드에 서로 다른 서비스 여러 개 필요할 때 (예: OpenWebUI + Ollama) |
| 멀티 레플리카 | 같은 서비스 부하 분산 필요할 때 |

⚠ 사용자에게 어떤 구조가 필요한지 명시적으로 물어보고 결정.

## CONSIDERATIONS — 작성 시 고려할 점

### 1. 이미지 (image)
- GitHub Actions로 빌드한 ghcr 이미지 URL 사용
- 기본 태그: `latest` (사용자가 다른 태그 명시한 경우 그 태그)
- 형식: `ghcr.io/<github-username>/<image-name>:<tag>`

### 2. 포트 (port)
- Dockerfile의 `EXPOSE` 값과 일치해야 함
- entrypoint.sh의 서비스 기동 포트와도 일치
- 예: ComfyUI는 8188

### 3. GPU 코드 (gpu)
- `gcube gpu list` 로 사용 가능한 GPU 코드 조회
- 사용자가 선택한 자원에 맞는 코드 사용
- ⚠ 가용 GPU로 표시되어도 실제 할당 실패할 수 있음
  → `common-issues.md` 참조

### 4. CUDA 버전 코드 (cuda)
- 코드 형식: `<major><minor 2자리><patch 1자리>`
- 예시: `12060` = CUDA 12.6.0, `12020` = CUDA 12.2.0, `12090` = CUDA 12.9.0
- gcube 표준: CUDA 12.9 → `12090`
- RTX 5090 단일 자원 한정 CUDA 13.0 → `13000` (추정, 사용 전 검증 권장)
- 정확한 코드는 `gcube gpu list` 출력으로 확인

### 5. maxConnection (동시 연결 수)

서비스로 한 번에 전달할 수 있는 HTTP 요청 또는 연결 수.
사용자 1명이 접속해도 웹페이지는 JS·CSS·이미지·API·WebSocket 요청을
동시에 여러 개 보낼 수 있으므로, 이 값은 실제 접속자 수와 다를 수 있음.

값이 낮으면 일부 화면이 로딩되지 않거나 503 오류 발생.
값이 높으면 컨테이너·GPU·메모리·프록시 리소스 사용량 증가.

**권장값 (gcube 웹콘솔 가이드)**:

| 서비스 유형 | 권장 maxConnection |
|---|---|
| GPU 추론 | 2 ~ 4 |
| 일반 API | 10 |
| 웹 UI | 20 ~ 40 |
| 고동시성 서비스 | 50 ~ 100 |

⚠ ComfyUI 같은 GPU 추론 + 웹 UI 혼합 서비스는 *"웹 UI"* 기준 적용.
실측 결과 20~30이 안정적.

### 6. 사용자 입력 환경변수 (containerEnvs)

⚠ 이 섹션의 환경변수는 `container-image-patterns/entrypoint.md` 의
CORE PRINCIPLE 에서 정의한 *"사용자 입력 환경변수"* 다.
이미지 내부 고정값은 여기에 X.

형식:
```yaml
containerEnvs:
  - key: TEXT_ENCODER_URLS
    value: "https://example.com/file1.safetensors https://example.com/file2.safetensors"
  - key: DIFFUSION_MODEL_URLS
    value: "https://example.com/model.safetensors"
```

- 같은 환경변수에 다수 값은 공백 한 칸으로 구분
- 환경변수 이름은 Dockerfile·entrypoint.sh와 정확히 일치

### 7. 클라우드 저장소 마운트 (userStorages)

결과물 보존이 필요한 경우 클라우드 저장소를 컨테이너에 마운트.

⚠ gcube 컨테이너 환경 특성상 결과물 보존하려면 마운트 거의 필수
(컨테이너 종료 시 컨테이너 내부 파일 사라짐).

#### 클라우드 저장소는 사용한다. 단 무엇을 마운트하느냐가 중요 (가장 중요)

클라우드 저장소 마운트는 적극 활용한다. 하지만 **무엇을 마운트하느냐**
가 핵심이다. 저장소 종류별로 용량·파일 크기 제약이 있어서 모든
데이터를 마운트할 수 있는 게 아니다.

**마운트에 적합 (이런 용도로 적극 활용)**:
- 사용자 작업물·결과물 (생성된 이미지·문서·작은 파일)
- 워크플로우·프롬프트·설정 파일
- 인증 토큰·API 키 (보안 검토 후)
- 사용자 커스터마이징 파일

**마운트에 절대 부적합 (마운트 X)**:
- **모델 파일** (GB 단위, 클라우드 저장소 용량 초과)
- 데이터셋 (대용량)
- 빌드 캐시·임시 파일

**큰 파일(모델 등)은 마운트가 아닌 다른 방법으로 처리**:
- 워크로드 yml의 `containerEnvs` 에 다운로드 URL 환경변수 설정
- entrypoint.sh가 첫 기동 시 그 URL에서 다운로드
- 자세한 패턴: `container-image-patterns/entrypoint.md` 참조

⚠ AI가 *"모델 파일도 클라우드 저장소에 마운트하면 보존됨"* 같은 추천 X.
이건 잘못된 추천. 클라우드 저장소는 **가벼운 결과물 보존용**으로만
사용하고, 모델 같은 무거운 파일은 환경변수 URL 다운로드로 처리한다.

#### 마운트 경로는 사용자가 결정한다

마운트할 컨테이너 내부 경로는 반드시 사용자에게 물어보고 사용자가
선택한 경로로 마운트한다. AI가 임의로 결정 X.

**사용자가 *"어디로 마운트하면 좋을지 모르겠다"* 라고 한 경우**

해당 서비스의 표준 결과물 디렉토리를 서칭으로 확인한다:
- 학습된 내용으로 답변 X
- 공식 문서·repo 등에서 서칭으로 확인
- 출처 URL 함께 제시
- 발행일 확인 (오래되면 다시 서칭)

서칭 결과를 사용자에게 보고:

> 서칭 결과 이 서비스의 표준 결과물 디렉토리는 다음과 같습니다:
> - `<디렉토리>` — <설명>
>
> 출처: <URL>
>
> 이 경로로 마운트하시겠어요? 또는 다른 경로 원하시면 알려주세요.

사용자가 추천을 받아들이면 그 경로로, 다른 경로를 원하면 그 경로로 마운트.

```yaml
userStorages:
  - storage: <사용자가 선택한 저장소>
    mountPath: <사용자가 선택한 경로>
```

⚠ 추천을 강요하지 말 것. 사용자가 *"내가 원하는 경로는 이거"* 라고
하면 그 경로로 진행.

### 8. 자원 변경 시 사용자 허락 필수

GPU 가용 표시와 실제 할당이 일치하지 않을 때가 가끔 있다.
배포 실패 시 자동으로 다른 자원으로 변경 X.
사용자에게 상황 설명 후 허락 받고 다른 자원으로 재시도.

## CONSTRAINTS
- maxConnection 권장값을 무시하고 임의 설정 X
- 환경변수 이름을 Dockerfile·entrypoint.sh와 다르게 X
- GPU·CUDA 코드는 학습 내용으로 단정 X. `gcube gpu list` 실행으로 확인
- 자원 변경은 반드시 사용자 허락 후
- 마운트 경로 임의 결정 X (사용자 결정)
- 사용자와 협의하지 않은 추가 필드 X

## REFERENCE
참고용 풀 예시: github.com/chaeyoon-08/gcube-cli-seminar
