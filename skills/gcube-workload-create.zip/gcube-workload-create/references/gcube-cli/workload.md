# gcube workload 명령

## PURPOSE
gcube CLI의 workload 명령 그룹 가이드. 워크로드 등록·조회·관리에 사용.

## STRUCTURE — 사용 가능한 명령

| 명령 | 목적 | 본 스킬 사용? |
|---|---|---|
| `workload register` | 새 워크로드 등록 | O |
| `workload list` | 워크로드 목록 조회 | O |
| `workload describe <SER>` | 워크로드 상세 조회 | O |
| `workload start <SER>` | 워크로드 시작 | △ (사용자 명시 요청 시) |
| `workload stop <SER>` | 워크로드 중지 | △ (사용자 명시 요청 시) |
| `workload logs <SER>` | 컨테이너 로그 조회 | O |
| `workload pods <SER>` | Pod 상태 조회 | O |
| `workload update <SER>` | 워크로드 설정 변경 | X (사용자 자산 변경) |
| `workload delete <SER>` | 워크로드 삭제 | X (사용자 자산 변경) |

## CONSIDERATIONS — 명령 사용 시 고려할 점

### 1. workload register — 워크로드 등록

두 가지 방식:

**A. yml 파일로 등록 (권장)**:
```bash
gcube workload register --file workload.yml
```
- 본 스킬은 yml 작성을 기본으로 함 (`workload-yml.md` 참조)
- 설정이 명시적이고 재사용 가능

**B. 옵션으로 등록**:
```bash
gcube workload register \
  --name <이름> \
  --image <이미지> \
  --port <포트> \
  --gpu <GPU 코드> \
  --cuda <CUDA 코드>
```
- 단순한 워크로드는 옵션만으로 가능
- 환경변수·마운트 많으면 yml 권장

⚠ 등록 후 SER 번호가 반환된다. 이 번호로 이후 작업 진행.

### 2. workload describe — 상태 확인

```bash
gcube workload describe <SER>
```

확인 항목:
- 상태: `Pending` → `Running` 전환 확인
- 자원: 실제 할당된 GPU·CPU·메모리
- 서비스 URL: 외부 접속 URL
- 환경변수: 설정한 값 정상 반영됐는지

⚠ `Pending` 상태가 오래 지속되면 자원 할당 실패 가능성
→ `common-issues.md` 참조

### 3. workload logs — 로그 확인

```bash
gcube workload logs <SER>
```

언제 사용:
- 서비스 기동 후 entrypoint.sh 자동화 진행 상황 확인
- 오류 발생 시 원인 분석
- 모델 다운로드 등 시간 걸리는 작업 진행 확인

옵션:
- `--follow` (또는 `-f`): 실시간 로그 스트림
- `--tail <N>`: 마지막 N줄만 조회

### 4. workload stop·start

```bash
gcube workload stop <SER>
gcube workload start <SER>
```

⚠ 안전 규칙: 기존 워크로드의 stop은 사용자가 명시적으로 요청한 경우만.
새 워크로드 작업 중 *"기존 워크로드 자리 비우려고 stop"* 같은 임의 판단 X.

## EXAMPLES — 자주 쓰는 흐름

### 새 워크로드 등록·검증 흐름

```bash
# 1. 워크로드 등록
gcube workload register --file workload.yml
# → SER 반환됨

# 2. 상태 확인 (Pending → Running 대기)
gcube workload describe <SER>

# 3. 로그로 entrypoint.sh 진행 확인
gcube workload logs <SER>

# 4. Running 확인 후 서비스 URL 접속 안내
```

## CONSTRAINTS
- `workload delete`·`workload update` 본 스킬에서 사용 X
- 기존 워크로드의 stop·start 임의 판단 X
- 사용자와 협의하지 않은 추가 명령 X
