# 자주 발생하는 문제

## PURPOSE
본 스킬 작업 중 자주 발생하는 문제와 해결 방법을 정리한 문서.
오류 발생 시 알려진 패턴인지 먼저 확인한다.

## CONTEXT — 본 문서의 사용 시점

다음 상황에서 본 문서를 참조한다:
- 빌드 중 오류 발생
- 워크로드 등록 실패
- 컨테이너 로그에서 오류 발견
- 서비스 URL 응답 없음
- 자원 할당 실패

⚠ 본 문서에 없는 새로운 오류는 메시지 그대로 분석 + 서칭으로 해결.
학습된 내용으로 추측 X.

## ISSUES — 알려진 문제와 해결책

### 1. GitHub Actions 디스크 부족

**증상**:
- 빌드 중 *"No space left on device"* 오류
- 특히 GPU 베이스 이미지 (PyTorch + CUDA devel 등 ~15GB) 사용 시

**원인**:
- GitHub Actions 무료 러너의 디스크는 14GB 정도
- 큰 베이스 이미지 + Buildx 캐시 합치면 초과

**해결**:
build.yml 에 `Free disk space` step 추가 (~30GB 확보):

```yaml
- name: Free disk space
  uses: jlumbroso/free-disk-space@main
  with:
    tool-cache: true
    android: true
    dotnet: true
    haskell: true
    large-packages: true
    swap-storage: true
```

**참조**: `container-image-patterns/github-actions.md` 의 *"디스크 부족 회피"* 섹션

---

### 2. PEP 668 (Ubuntu 24.04 시스템 Python 보호)

**증상**:
- Dockerfile 빌드 중 pip install 실패
- 오류 메시지: *"externally-managed-environment"*

**원인**:
- Ubuntu 24.04+ 시스템 Python은 PEP 668 활성
- pip install이 시스템 Python을 변경하지 못하도록 보호

**해결**:
Dockerfile 에 다음 중 하나 추가:

```dockerfile
# A. 환경변수로 우회
ENV PIP_BREAK_SYSTEM_PACKAGES=1

# B. pip install 시 플래그
RUN pip install --break-system-packages <패키지>
```

**참조**: https://peps.python.org/pep-0668/

---

### 3. GPU 자원 가용 표시 vs 실제 할당 불일치

**증상**:
- `gcube gpu list` 에서 가용으로 표시됨
- 워크로드 등록 시 자원 할당 실패
- 워크로드 상태가 `Pending` 에서 오래 지속됨

**원인**:
- gcube 플랫폼의 가용 표시와 실제 할당 상태가 일치하지 않을 때가 있음
- 다른 워크로드와 동시 등록 경합 등

**해결**:
1. 사용자에게 상황 설명
2. 다른 자원으로 시도할지 사용자에게 허락 받기
3. 사용자 허락 후 다른 GPU 코드로 재시도
4. 자동 재시도 X

⚠ 안전 규칙: 자원 변경은 반드시 사용자 허락 후. 임의 변경 X.

---

### 4. maxConnection 부족 시 503 오류

**증상**:
- 서비스 URL 접속 시 일부 화면 로딩 실패
- 503 Service Unavailable 오류
- 웹 UI 의 CSS·JS·이미지 일부만 로드됨

**원인**:
- 사용자 1명이 접속해도 웹페이지는 JS·CSS·이미지·API 요청을
  동시에 여러 개 보냄
- maxConnection 값이 낮으면 일부 요청 차단

**해결**:
워크로드 yml 의 `maxConnection` 값 증가. 권장값:

| 서비스 유형 | 권장값 |
|---|---|
| GPU 추론 | 2 ~ 4 |
| 일반 API | 10 |
| 웹 UI | 20 ~ 40 |
| 고동시성 서비스 | 50 ~ 100 |

**참조**: `workload-yml.md` 의 5번 항목

---

### 5. 컨테이너 외부에서 서비스 URL 접속 불가

**증상**:
- 워크로드 상태 Running
- 컨테이너 로그에 오류 없음
- 서비스 URL 접속 시 응답 없음 또는 connection refused

**원인 후보**:
- entrypoint.sh 또는 Dockerfile 에서 서비스 호스트를 `127.0.0.1` 또는
  `localhost` 로 설정 → 컨테이너 외부 접속 불가
- 포트 불일치 (Dockerfile `EXPOSE` ≠ 실제 기동 포트 ≠ 워크로드 yml `port`)

**해결**:
1. entrypoint.sh 의 서비스 기동 호스트를 `0.0.0.0` 으로 설정
2. Dockerfile `EXPOSE`, entrypoint.sh 기동 포트, 워크로드 yml `port`
   세 곳이 모두 일치하는지 확인

**참조**: `container-image-patterns/entrypoint.md` 의 *"서비스 기동"* 섹션

---

### 6. 디렉토리 없음으로 인한 서비스 오류

**증상**:
- 컨테이너 로그에 디렉토리 관련 오류
- 예: ComfyUI 의 `/api/userdata` 404 오류

**원인**:
- 서비스가 사용하는 디렉토리가 컨테이너 안에 없음
- entrypoint.sh 에서 mkdir 안 한 경우

**해결**:
Dockerfile 에서 필요한 디렉토리를 미리 생성:

```dockerfile
RUN mkdir -p \
        <필요한 디렉토리 1> \
        <필요한 디렉토리 2>
```

⚠ 디렉토리 생성은 entrypoint.sh X, Dockerfile에서 처리.

**참조**: `container-image-patterns/dockerfile.md` 의 *"디렉토리 사전 생성"* 섹션

---

### 7. 모델 다운로드 실패

**증상**:
- entrypoint.sh 로그에 wget 다운로드 실패
- 컨테이너 기동 후 모델 파일 없음

**원인 후보**:
- 환경변수의 URL 이 잘못되거나 만료됨
- 네트워크 접근 제한 (인증 필요한 URL 등)
- 디스크 공간 부족

**해결**:
1. 환경변수의 URL 을 사용자에게 확인 요청
2. 인증 필요한 URL 이면 자격 증명 관련 추가 환경변수 필요
3. 디스크 공간은 워크로드 자원에서 확인

⚠ URL 자체를 학습 내용으로 단정 X. 사용자 또는 공식 출처 확인.

---

### 8. ghcr push 권한 오류

**증상**:
- GitHub Actions 빌드 중 *"unauthorized"* 또는 *"denied"* 오류
- 이미지가 ghcr 에 push 되지 않음

**원인**:
- build.yml 에 `packages: write` 권한 누락
- 또는 repo 설정에서 Actions 의 write 권한 비활성화

**해결**:
1. build.yml 에 권한 추가:
```yaml
permissions:
  contents: read
  packages: write
```

2. GitHub repo 의 Settings → Actions → General → Workflow permissions
   에서 *"Read and write permissions"* 활성화

**참조**: `container-image-patterns/github-actions.md` 의 *"ghcr push 권한 설정"* 섹션

---

### 9. 이미지 이름 대소문자 오류

**증상**:
- GitHub Actions 빌드 중 이미지 push 실패
- 오류 메시지: *"repository name must be lowercase"*

**원인**:
- ghcr 의 이미지 이름·소유자는 소문자만 가능
- GitHub 사용자명에 대문자가 있으면 자동 매핑이 안 됨

**해결**:
build.yml 의 이미지 태그를 명시적으로 소문자로:

```yaml
tags: ghcr.io/${{ github.repository_owner }}/<image-name>:latest
```

또는 직접 소문자로 박기:
```yaml
tags: ghcr.io/myname/myimage:latest
```

---

### 10. 컨테이너 첫 기동 시간이 매우 김

**증상**:
- 워크로드 Running 상태이지만 서비스 URL 응답 없음
- 컨테이너 로그에 entrypoint.sh 가 모델 다운로드 중

**원인**:
- 첫 기동 시 모델 파일 다운로드 (GB 단위)
- 클라우드 저장소 마운트 후 캐시 작업

**해결**:
- 정상 동작. 모델 크기에 따라 수 분 ~ 수십 분 소요
- `gcube workload logs <SER> --follow` 로 진행 상황 확인
- 다운로드 완료 후 자동 기동

⚠ 재기동 시에는 이미 다운로드된 파일 skip → 빠르게 기동.
(entrypoint.sh 의 *"이미 존재 파일 skip"* 패턴 덕분)

---

### 11. 클라우드 저장소 마운트 용량 제약

**증상**:
- 마운트한 클라우드 저장소에 GB 단위 파일 저장 실패
- 또는 마운트 자체가 정상 동작 안 함

**원인**:
- 마운트 가능한 클라우드 저장소 종류별로 용량·파일 크기 제약 다름
- 예: Dropbox 등 일부 저장소는 가벼운 설정·인증 파일만 가능
  (GB 단위 모델 파일 저장 X)

**해결**:
1. 사용자에게 어떤 저장소를 사용할지 확인
2. 해당 저장소의 용량·파일 크기 제약 서칭으로 확인
3. 제약을 사용자에게 짚어주고 적합 여부 함께 결정
4. 큰 파일(모델 등)은 entrypoint.sh 에서 환경변수 기반 다운로드로 처리
   (마운트 저장소에 미리 저장 X)

⚠ 저장소별 정확한 제약은 학습 내용 X. 서칭 또는 사용자 확인.

---

### 12. 모델 이름이 비슷한 다른 모델 사용 (버전 혼동)

**증상**:
- 모델 다운로드는 성공
- 서비스에서 모델 로드 시 누락 파일·호환성 오류
- 또는 서비스 동작이 의도와 다름

**원인**:
- 모델 이름이 비슷한 다른 버전을 잘못 사용
- 예: *"ACE-Step v1"* 과 *"ACE-Step v1.5 XL"* 은 다른 모델인데
  비슷한 이름이라 혼동
- 학습된 모델 정보가 최신과 다를 수 있음

**해결**:
1. 모델 정보는 학습 내용으로 단정 X
2. 공식 문서·repo 에서 정확한 모델 이름·버전·다운로드 URL 서칭
3. 출처 URL 사용자에게 함께 제시
4. 사용자가 직접 검증할 수 있게

⚠ *"이 모델은 이런 것 같다"* 추측 금지. 공식 출처 확인 필수.

**참조**: 핵심 원칙 3번 (모든 답변·결정에 출처)

---

### 13. 재배포 시 컨테이너 내부 데이터 초기화

**증상**:
- 워크로드 재배포 후 이전 작업한 파일·모델·설정이 사라짐
- 첫 기동 시처럼 모델 다운로드부터 다시 시작

**원인**:
- 워크로드 재배포 시 컨테이너 내부 파일시스템은 새로 시작
- 클라우드 저장소에 마운트되지 않은 디렉토리의 모든 데이터 휘발

**해결**:
1. 보존이 필요한 디렉토리는 워크로드 yml 에 마운트 추가
2. 사용자에게 보존이 필요한 디렉토리가 무엇인지 물어보고 결정
3. 마운트 경로는 사용자가 선택 (`workload-yml.md` 7번 참조)

⚠ 모든 디렉토리를 마운트할 필요 X. 사용자가 *"보존이 필요한"* 디렉토리만.
큰 파일은 클라우드 저장소 용량 제약 고려 (이슈 11번 참조).

---

### 14. ComfyUI 모델 호환성 — ComfyUI 공식 제공 모델만 사용

**증상**:
- 모델 다운로드는 성공
- ComfyUI에서 모델 로드 시 오류 (포맷 불일치·텐서 키 누락 등)
- 또는 추론 결과가 의도와 다름·노드 연결 실패

**원인**:
- ComfyUI는 일반 Hugging Face 원본 모델을 그대로 못 쓰는 경우가 많음
- ComfyUI 전용으로 변환·분할된 모델 파일 필요 (split_files 형식 등)
- 원본 모델 저장소와 ComfyUI 제공 저장소가 다름

**해결**:
- 모델 선택 시 **ComfyUI 공식 제공 모델 저장소** 에서 가져온다
- 공식 모델 저장소: Hugging Face 의 **Comfy-Org** 계정 (https://huggingface.co/Comfy-Org)
- 또는 ComfyUI 공식 docs 의 모델별 페이지에서 안내하는 URL
- 예: Z-Image-Turbo 는 Comfy-Org/z_image_turbo 의 split_files 경로 사용
- 출처: https://docs.comfy.org/

**모델 선택 시 절차**:
1. 사용자가 사용하려는 모델 확인 (예: *"Z-Image-Turbo"*, *"Flux"*, *"SDXL"*)
2. ComfyUI 공식 docs (https://docs.comfy.org/) 또는 Comfy-Org Hugging Face 저장소 서칭
3. ComfyUI 제공 모델 파일 URL 확보 (출처 함께)
4. 일반 원본 모델 저장소 URL 사용 X
5. 사용자에게 *"ComfyUI 공식 제공 모델로 사용한다"* 명시

⚠ AI가 학습된 내용으로 일반 Hugging Face 원본 모델 URL 단정 X.
ComfyUI 공식 제공 모델 저장소·docs 에서 서칭으로 확인.

**참조**: SKILL.md 공식 자산 우선 원칙 (2순위: 공식 모델 저장소 따라가는 커스텀 이미지)

## CONSTRAINTS

- 본 문서에 없는 오류는 학습 내용으로 단정 X
- 오류 메시지 그대로 분석 + 서칭으로 해결
- 모든 해결책 제시 시 출처 URL 함께 (서칭 정보는 최신 기준)
- 사용자 자산 변경 가능성 있는 해결책은 사용자 허락 후

## REFERENCE
새로운 시행착오·해결책 발견 시 본 문서에 추가 권장.
