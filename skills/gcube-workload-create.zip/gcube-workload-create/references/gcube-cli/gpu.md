# gcube gpu 명령

## PURPOSE
gcube CLI의 gpu 명령 가이드. GPU 자원 조회·선택에 사용.

## STRUCTURE — 사용 가능한 명령

| 명령 | 목적 |
|---|---|
| `gpu list` | 사용 가능한 GPU 자원 코드·스펙 조회 |
| `gpu list --all` | 모든 GPU 옵션 조회 (가용 여부 무관) |

## CONSIDERATIONS — 사용 시 고려할 점

### 1. gpu list — 자원 선택 전 반드시 실행

```bash
gcube gpu list
```

출력에 다음 정보 포함:
- GPU 코드 (워크로드 yml `gpu` 필드에 사용)
- GPU 모델 (RTX 4090·5090 등)
- VRAM 크기
- CUDA 호환 버전
- 가용 여부

### 2. 자원 가용 표시 vs 실제 할당 불일치

⚠ 가용 표시와 실제 할당이 일치하지 않을 때가 가끔 있다.
- 가용으로 표시되어도 등록 시 자원 할당 실패할 수 있음
- 자원 할당 실패 시 다른 자원으로 자동 변경 X
- 사용자에게 상황 설명 후 허락 받고 재시도

상세 처리는 `common-issues.md` 참조.

### 3. CUDA 호환 버전 확인

- gcube 표준: CUDA 12.9 까지
- RTX 5090 단일 자원 한정 CUDA 13.0 가능
- 워크로드 yml의 `cuda` 필드 값은 `gpu list` 출력 기준으로 결정

## EXAMPLES

```bash
# 사용 가능한 GPU 자원 조회
gcube gpu list

# 모든 GPU 옵션 조회 (가용 여부 무관)
gcube gpu list --all
```

## CONSTRAINTS
- GPU·CUDA 코드 학습 내용으로 단정 X
- 자원 변경 시 사용자 허락 필수
