# gcube CLI 패턴

## PURPOSE
gcube CLI 명령어 레퍼런스 인덱스. 본 스킬 작업에서 자주 사용하는
명령 그룹별로 세부 가이드를 분리.

## CONTEXT — 본 문서의 범위
gcube CLI 전체 명령(20개) 중 본 스킬 작업(워크로드 생성·관리)에
필요한 명령만 다룬다.

사전 가정:
- 사용자가 gcube CLI 설치 완료
- 사용자가 인증 완료 (`gcube configure status` 로 확인 가능)
- 인증 안 되어 있으면 사용자에게 요청

## REFERENCE INDEX — 명령 그룹별 세부 가이드 참조 시점

| 작업 | 참조 파일 |
|---|---|
| 워크로드 등록·조회·시작·중지·로그 확인 | `gcube-cli/workload.md` |
| GPU 자원 조회·선택 | `gcube-cli/gpu.md` |
| 클라우드 저장소 조회 | `gcube-cli/storage.md` |
| 자격 증명 관리 (Docker Hub·AWS ECR 등) | `gcube-cli/credential.md` |

## CONSTRAINTS — 모든 명령 공통 원칙

- `workload delete`·`workload update`·`credential delete` 본 스킬에서 사용 X
  (사용자가 명시적으로 요청한 경우만 사용)
- 기존 워크로드의 stop·start 임의 판단 X (사용자 명시 요청 시만)
- GPU·CUDA 코드 학습 내용으로 단정 X (항상 `gpu list` 출력으로 확인)
- 자원 변경 시 사용자 허락 필수
- 사용자와 협의하지 않은 추가 명령 X

## REFERENCE
gcube CLI 전체 명령(20개) 참조 예시:
github.com/chaeyoon-08/gcube-cli-seminar
