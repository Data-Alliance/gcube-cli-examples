# entrypoint.sh 패턴

## PURPOSE
entrypoint.sh 작성 시 고려해야 할 핵심 포인트 + 검증된 예시.

## CONTEXT — 왜 entrypoint.sh가 필요한가
이미지 빌드 시점에 모든 것을 굽지 않고 첫 기동 시점에 처리하는 이유:
- 모델 파일은 GB 단위라 이미지 포함 시 크기 폭증
- 같은 이미지로 환경변수만 바꿔 다른 모델·구성 재사용 가능
- 모델 URL 변경 시 이미지 재빌드 불필요

## CORE PRINCIPLE — 환경변수 두 종류 구분 (가장 중요)

entrypoint.sh를 만들 때 가장 중요한 것은 **두 종류의 환경변수를
명확히 구분**해서 설계하는 것이다.

| 종류 | 정의 | 위치 | 사용자가 바꿀 수 있나 |
|---|---|---|---|
| 사용자 입력 환경변수 | gcube 워크로드 생성 시 사용자가 직접 입력 | 워크로드 yml `containerEnvs` | O |
| 이미지 내부 고정 환경변수 | 이미지 빌드 시 고정 | Dockerfile `ENV` 또는 entrypoint.sh 내부 | X |

**사용자 입력 환경변수로 만들어야 할 것**:
- 모델·데이터 다운로드 URL
- 배포마다 다른 설정값
- 외부 서비스 인증 토큰
- 사용자가 *"이건 바꿀 수 있으면 좋겠다"* 라고 요구한 값

**이미지 내부 고정값으로 만들어야 할 것**:
- 서비스 호스트 (`0.0.0.0` 고정)
- 서비스 포트 (서비스별 표준 포트)
- 디렉토리 베이스 경로 (이미지 구조에 의존)

이 구분은 1단계 정보 수집·2단계 설계에서 사용자와 함께 결정한다.
entrypoint.sh 작성 시점에는 이미 결정된 구분에 따라 작성한다.

## CONSIDERATIONS — 작성 시 고려할 점

### 1. 사용자 입력 환경변수 처리
- 빈 값·없는 변수 skip 처리
- 같은 종류 다수 입력 시 구분자 정의 (공백 한 칸 권장)
- 배열 + parameter expansion 패턴이 가독성·확장성 ↑

### 2. 다운로드 함수
- 이미 존재 파일 skip (재기동 빠르게)
- URL 쿼리 파라미터 제거 (`cut -d'?' -f1`)
- 디렉토리 생성은 entrypoint X, Dockerfile에서 사전 처리

### 3. 서비스 기동
- 호스트는 항상 `0.0.0.0` (localhost·127.0.0.1 X — 컨테이너 외부 접속 불가)
- `exec` 사용 (자식 프로세스 X, 신호 처리 정상)
- 작업 디렉토리 이동 후 실행

### 4. 로그 형식 (선택)
컨테이너 로그 가독성을 위해 prefix 형식 권장:
`[ DOING ] / [ OK ] / [ SKIP ] / [ START ] / [ DONE ]`

## EXAMPLES — 검증된 패턴

### 예시 1 — 환경변수 → 폴더 매핑 (배열 + parameter expansion)

여러 카테고리의 모델·리소스를 다운로드하는 경우 다음 패턴:

```bash
# 환경변수 → 폴더 매핑 배열
DOWNLOAD_MAP=(
    "TEXT_ENCODER_URLS:text_encoders"
    "DIFFUSION_MODEL_URLS:diffusion_models"
    "VAE_URLS:vae"
)

for entry in "${DOWNLOAD_MAP[@]}"; do
    var_name="${entry%%:*}"     # 콜론 앞: 환경변수명
    folder="${entry##*:}"        # 콜론 뒤: 폴더명
    urls="${!var_name}"          # 간접 참조로 값 조회

    if [ -z "$urls" ]; then
        continue
    fi

    for url in $urls; do
        download_url "$url" "$folder"
    done
done
```

**왜 이 방식인가**:
- 카테고리 추가·삭제가 배열 한 줄로 끝남
- 환경변수명과 폴더명을 한 곳에서 관리
- 직접 나열보다 가독성·확장성 ↑

### 예시 2 — 다운로드 함수

```bash
download_url() {
    local url="$1"
    local folder="$2"
    local file_name
    file_name=$(basename "$url" | cut -d'?' -f1)
    local target="${MODEL_BASE}/${folder}/${file_name}"

    if [ -f "$target" ]; then
        echo "[ SKIP  ] ${folder}/${file_name} (이미 존재)"
        return 0
    fi

    echo "[ DOING ] ${folder}/${file_name}"
    wget -q --show-progress -O "$target" "$url"
    echo "[ OK    ] ${folder}/${file_name}"
}
```

**핵심 동작**:
- URL 쿼리 파라미터(`?token=...`) 제거
- 이미 존재 파일 skip
- 한 가지 일만 (단순 명확)

### 예시 3 — 단순 단일 URL 다운로드

여러 카테고리가 아닌 단일 모델·체크포인트만 받는 경우 더 단순:

```bash
if [ -n "$CHECKPOINT_URL" ]; then
    target="/app/models/$(basename "$CHECKPOINT_URL" | cut -d'?' -f1)"
    if [ ! -f "$target" ]; then
        wget -q --show-progress -O "$target" "$CHECKPOINT_URL"
    fi
fi
```

### 예시 4 — 서비스 기동

```bash
SERVICE_HOST="0.0.0.0"
SERVICE_PORT="<포트>"

cd /app/<서비스>
exec <진입점 명령> --listen "$SERVICE_HOST" --port "$SERVICE_PORT"
```

## CONSTRAINTS
- 호스트를 0.0.0.0 외 값으로 설정 X
- 모델·리소스를 URL이 아닌 외부 호스팅 스크립트로 다운로드 X
- 환경변수 값 추측 사용 X. 빈 값 체크 필수
- entrypoint.sh에서 mkdir X (Dockerfile에서 사전 처리)
- 사용자 입력 vs 고정값 구분 없이 작성 X (CORE PRINCIPLE 참조)
- 사용자와 협의하지 않은 추가 작업 X

## REFERENCE
참고용 풀 예시: github.com/chaeyoon-08/gcube-cli-seminar
