# GitHub Actions 빌드 패턴

## PURPOSE
GitHub Actions로 컨테이너 이미지를 자동 빌드해서 ghcr에 push할 때
고려해야 할 핵심 포인트.

## CONTEXT — 왜 GitHub Actions를 쓰는가
- 로컬 빌드는 디스크·CPU·시간 부담 큼 (특히 GPU 베이스 이미지는 ~15GB)
- 사용자의 로컬 환경 의존성 없이 일관된 빌드 환경 확보
- main 브랜치 push 시 자동 빌드 → ghcr push로 배포 자동화
- gcube 워크로드는 ghcr 이미지를 그대로 가져다 쓸 수 있음

## STRUCTURE — build.yml 기본 구조

```yaml
name: <빌드 이름>

on:
  push:
    branches: [main]
  workflow_dispatch:  # 수동 빌드 트리거

jobs:
  build-and-push:
    runs-on: ubuntu-latest
    permissions:
      contents: read
      packages: write       # ghcr push 권한

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Free disk space      # 디스크 부족 회피
        run: ...

      - name: Login to ghcr
        uses: docker/login-action@v3
        with:
          registry: ghcr.io
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}

      - name: Build and push
        uses: docker/build-push-action@v5
        with:
          push: true
          tags: ghcr.io/<owner>/<image>:latest
```

## CONSIDERATIONS — 작성 시 고려할 점

### 1. 디스크 부족 회피 (Free disk space step)

GitHub Actions 무료 러너의 디스크는 14GB 정도.
GPU 베이스 이미지(PyTorch + CUDA devel ~15GB) + Buildx 캐시 합치면 초과.

다음 step을 추가해 ~30GB 확보:

```yaml
- name: Free disk space
  uses: jlumbroso/free-disk-space@main
  with:
    tool-cache: true
    android: true
    dotnet: true
    haskell: true
    large-packages: true
    swap-storage: true
```

→ 작은 이미지(< 5GB)는 이 step 불필요. 큰 이미지에만 추가.

### 2. ghcr push 권한 설정

```yaml
permissions:
  contents: read
  packages: write
```

- `packages: write` 누락 시 *"unauthorized"* 오류
- repo 설정에서도 Actions의 write 권한 활성화 확인 필요

### 3. 태그 전략

**기본 태그: `latest`**

특별한 요구가 없으면 `latest` 를 기본 태그로 사용한다.
`main` 브랜치 push 시 `latest` 태그로 ghcr에 push.

```yaml
- name: Build and push
  uses: docker/build-push-action@v5
  with:
    push: true
    tags: ghcr.io/<owner>/<image>:latest
```

**사용자가 다른 태그 전략을 원하는 경우 수용**

사용자가 다음과 같이 요구하면 해당 방식으로 진행:
- 버전 태그 (예: `v1.0.0`, `2026-05`)
- 커밋 해시 태그
- 브랜치별 태그
- 다중 태그 (예: `latest` + 버전 동시)

다중 태그 예시:

```yaml
tags: |
  ghcr.io/<owner>/<image>:latest
  ghcr.io/<owner>/<image>:v1.0.0
```

⚠ 사용자가 다른 태그 전략을 명시하지 않으면 묻지 말고 `latest` 사용.
사용자가 명시할 때만 해당 방식 적용.

### 4. Buildx 캐시 활용

빌드 시간 단축 위해 GitHub Actions 캐시 사용:

```yaml
- name: Set up Docker Buildx
  uses: docker/setup-buildx-action@v3

- name: Build and push
  uses: docker/build-push-action@v5
  with:
    push: true
    cache-from: type=gha
    cache-to: type=gha,mode=max
    tags: ...
```

→ 첫 빌드 후 부분 변경 시 재빌드 빠름.

### 5. 트리거 설정

- `push: branches: [main]`: main 브랜치 push 시 자동 빌드
- `workflow_dispatch`: GitHub UI에서 수동 빌드 가능 (디버깅·재빌드용)
- 다른 브랜치도 빌드하려면 추가

### 6. 이미지 이름·소유자

`ghcr.io/<github-username>/<image-name>:<tag>` 형식.
- `<github-username>` 은 소문자만 가능 (대문자 사용 시 오류)
- `<image-name>` 은 보통 repo 이름 그대로

## CONSTRAINTS
- `packages: write` 권한 누락 시 push 실패
- 큰 이미지(GPU 베이스 등)에서 Free disk space step 누락 시 빌드 실패
- 사용자와 협의하지 않은 추가 step X
- 비밀(secret) 값을 로그에 출력 X

## REFERENCE
참고용 풀 예시: github.com/chaeyoon-08/gcube-cli-seminar 의 `.github/workflows/build.yml`
